#!/bin/bash

CORES=$(grep -c processor /proc/cpuinfo)

sudo service klipper stop
cd ~/klipper

# Update mcu rpi

echo "Start update mcu rpi"
echo ""
make clean KCONFIG_CONFIG=/home/ente/printer_data/config/scriptconfig.host
make menuconfig KCONFIG_CONFIG=/home/ente/printer_data/config/script/config.host
make -j $CORES KCONFIG_CONFIG=/home/ente/printer_data/config/script/config.host
read -p "mcu rpi firmware built, please check above for any errors. Press [Enter] to continue flashing, or [Ctrl+C] to abort"
make flash KCONFIG_CONFIG=/home/ente/printer_data/config/script/config.host
echo "Finish update mcu rpi"
echo ""

# Update mcu XYE
#echo "Start update mcu nano"
#echo ""
#cp src/Makefile src/Makefile.old
#cp /home/ente/printer_data/config/script/Makefile src/Makefile
#make clean KCONFIG_CONFIG=/home/ente/printer_data/config/script/config.nano
#kein make menu machen, macht kconf putt
#make menuconfig KCONFIG_CONFIG=/home/ente/printer_data/config/script/config.nano
#make -j $CORES KCONFIG_CONFIG=/home/ente/printer_data/config/script/config.nano
#read -p "mcu Arduino Nano firmware built, please check above for any errors. Press [Enter] to continue, or [Ctrl+C] to abort"
#avrdude -carduino -patmega328p -P/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0 -b57600 -D -Uflash:w:out/klipper.elf.hex:i
#cp src/Makefile.old src/Makefile
#echo "Finish update mcu nano"
#echo ""

# Update mcu Z
echo "Start update mcu R4"
echo ""
make clean KCONFIG_CONFIG=/home/ente/printer_data/config/script/config.r4
make menuconfig KCONFIG_CONFIG=/home/ente/printer_data/config/script/config.r4
make -j $CORES KCONFIG_CONFIG=/home/ente/printer_data/config/script/config.r4
read -p "mcu R4 firmware built, please check above for any errors. Press [Enter] to continue, or [Ctrl+C] to abort"
make flash FLASH-DEVICE=/dev/serial/by-id/usb-Klipper_rp2040_E6609CB2D3259224-if00
echo "Finish update mcu R4"
echo ""

sudo service klipper start

#!/bin/bash

chmod +x ~/printer_data/config/script/updatemcu.sh
sleep 3
~/printer_data/config/script/updatemcu.sh
